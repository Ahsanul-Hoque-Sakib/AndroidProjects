package com.example.user.agecalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    TextView showAge,EvenOdd,PrimeText,Binary;
    EditText inputBirthYear;
    Button Calculate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        showAge = findViewById(R.id.showage);
        inputBirthYear = findViewById(R.id.inputBirthYear);
        Calculate = findViewById(R.id.calculate);
        EvenOdd = findViewById(R.id.EvenOdd);
        PrimeText = findViewById(R.id.primeText);
        Binary = findViewById(R.id.BinaryGenerator);
        LinearLayout linearLayout = findViewById(R.id.mainlayout);

        inputBirthYear.setCursorVisible(false);
        inputBirthYear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputBirthYear.setCursorVisible(true);
                inputBirthYear.setHint("");
            }
        });

        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(inputBirthYear.getText().toString().equals("")){
                    inputBirthYear.setHint("Enter Birth Year");
                    inputBirthYear.setCursorVisible(false);
                    inputBirthYear.setText("");
                }


            }
        });

        showAge.setVisibility(View.GONE);
        EvenOdd.setVisibility(View.GONE);
        PrimeText.setVisibility(View.GONE);
        Binary.setVisibility(View.GONE);

        Calculate();


    }

    public void Calculate(){
        Calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(inputBirthYear.getText().toString().equals("")){
                    Toast.makeText(MainActivity.this,"Field Can Not be Empty",Toast.LENGTH_LONG).show();
                }
                else{
                    String input_age= inputBirthYear.getText().toString();
                    int birthDate= Integer.parseInt(input_age);


                    Calendar calendar= Calendar.getInstance();

                    int currentYear= calendar.get(Calendar.YEAR);
                    int age= currentYear-birthDate;

                    showAge.setText("Your current age is:::"+age);
                    showAge.setVisibility(View.VISIBLE);
                    EvenOdd(age);
                }


            }
        });
    }

    public void EvenOdd(int age){
        String text;
        if(age%2==0){
            text = age +" is your even age";
            EvenOdd.setText(text);
            EvenOdd.setVisibility(View.VISIBLE);
            primeNumber(age);

            Binary.setText("");
            Binary.setVisibility(View.GONE);
        }
        else{
            text = age +" is your odd age";
            EvenOdd.setText(text);
            EvenOdd.setVisibility(View.VISIBLE);
            PrimeText.setText("");

            PrimeText.setVisibility(View.GONE);

            DecimalToBinary(age);
        }
    }

    public void primeNumber(int age){
        int increase =0;
        String primeText;
        for(int i =1;i<=age;i++){
            if(age%i==0){
                increase++;
            }
        }

        if(increase==2){
            primeText= age +" is Prime Number";
            PrimeText.setText(primeText);
            PrimeText.setVisibility(View.VISIBLE);
        }
        else{
            primeText = age +" is not Prime Number";
            PrimeText.setText(primeText);
            PrimeText.setVisibility(View.VISIBLE);
        }
    }


    public void DecimalToBinary(int age){

        int Age = age;
        String binary="";
        int binaryNum[] = new int [1000];
        int i = 0;
        while (age > 0) {

            binaryNum[i] = age % 2;
            age = age / 2;
            i++;

        }
        for (int j = i - 1; j >= 0; j--) {
            binary = binary + binaryNum[j];
        }
        Binary.setText(Age +" binary is::"+ binary);
        Binary.setVisibility(View.VISIBLE);

    }





}
