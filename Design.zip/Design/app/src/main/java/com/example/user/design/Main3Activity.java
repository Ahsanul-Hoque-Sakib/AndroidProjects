package com.example.user.design;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity {

    private ListView listView;
    String[] countryNames;
    String[] description;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        countryNames = getResources().getStringArray(R.array.countryNames);
        description = getResources().getStringArray(R.array.description);

        listView = findViewById(R.id.lisViewId);
        CustomAdapter adapter = new CustomAdapter(this,countryNames);
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String value = countryNames[position];
                String desc = description[position];
                AlertDialog.Builder builder = new AlertDialog.Builder(Main3Activity.this);
                View bv = getLayoutInflater().inflate(R.layout.popup,null);

                TextView countryname = bv.findViewById(R.id.countryName);
                TextView description = bv.findViewById(R.id.description);

                countryname.setText(value);
                description.setText(desc);



                builder.setView(bv);
                final AlertDialog dialog = builder.create();
                dialog.show();

                Toast.makeText(Main3Activity.this,value,Toast.LENGTH_LONG).show();
            }
        });
    }
}
