package com.example.user.datepicker;

import android.graphics.Typeface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button showbutton;
    DatePicker datePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Typeface mycustomfont = Typeface.createFromAsset(getAssets(),"fonts/Walkway_Bold.ttf");
        final Typeface mycustomfont1 = Typeface.createFromAsset(getAssets(),"fonts/Walkway_Black.ttf");
        final Typeface mycustomfont2 = Typeface.createFromAsset(getAssets(),"fonts/Walkway_UltraBold.ttf");
        showbutton = findViewById(R.id.showbtn);
        datePicker = findViewById(R.id.datepicker);
        showbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                View bv = getLayoutInflater().inflate(R.layout.popup,null);
                TextView date = bv.findViewById(R.id.popdate);
                TextView month = bv.findViewById(R.id.popmonth);
                TextView leapyear = bv.findViewById(R.id.popleapyear);
                ImageButton exit = bv.findViewById(R.id.exit);
                date.setText(showdate());
                date.setTypeface(mycustomfont1);
                month.setText(monthEvenOdd());
                month.setTypeface(mycustomfont);
                leapyear.setText(leapyer());
                leapyear.setTypeface(mycustomfont2);

                builder.setView(bv);
                final AlertDialog dialog = builder.create();
                dialog.show();

                exit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.cancel();
                    }
                });

            }
        });

    }

    public String showdate(){
        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append(datePicker.getDayOfMonth()+"/");
        stringBuilder.append(datePicker.getMonth()+1+"/");
        stringBuilder.append(datePicker.getYear());

        return stringBuilder.toString();
    }

    public String monthEvenOdd(){
        int noOFMonth = datePicker.getMonth()+1;
        String text;
        if(noOFMonth%2==0){
            if(noOFMonth==2){
                text = "This is "+noOFMonth+"nd Month which is Even";
            }
            else {
                text = "This is " + noOFMonth + "th Month which is Even";
            }
        }
        else{
            if(noOFMonth==1){
                text = "This is "+noOFMonth+"st Month which is Odd";
            }
            else if(noOFMonth==3){
                text = "This is "+noOFMonth+"rd Month which is Odd";
            }
            else {
                text = "This is " + noOFMonth + "th Month which is Odd";
            }
        }
        return text;
    }

    public String leapyer() {
        int year = datePicker.getYear();
        String txtyear;

        if ((year % 400) == 0){
            txtyear = ( year+" is a leap year");
    }
        else if ((year % 100) == 0) {
            txtyear = ( year+" is a not leap year");
        }
        else if ((year % 4) == 0) {
            txtyear = ( year+" is a leap year");
        }
        else {
            txtyear = ( year+" is not a leap year");
        }
        return txtyear;

    }

}
